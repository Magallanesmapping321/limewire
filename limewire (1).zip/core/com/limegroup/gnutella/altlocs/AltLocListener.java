package com.limegroup.gnutella.altlocs;

public interface AltLocListener {
    public void locationAdded(AlternateLocation loc);
}
