package com.limegroup.gnutella.io;


/**
 * Combines the ReadObserver & ChannelReader interface.
 */
public interface ChannelReadObserver extends ReadObserver, ChannelReader {
}
