package com.limegroup.gnutella.io;

public interface ReadTimeout {
    public long getReadTimeout();
}
