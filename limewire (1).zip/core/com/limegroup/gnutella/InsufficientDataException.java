package com.limegroup.gnutella;

public class InsufficientDataException extends Exception {}
