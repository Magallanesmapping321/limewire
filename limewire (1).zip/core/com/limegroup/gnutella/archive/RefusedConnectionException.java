package com.limegroup.gnutella.archive;

import java.io.IOException;

public class RefusedConnectionException extends IOException {

	private static final long serialVersionUID = -1734468926065538629L;

	public RefusedConnectionException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RefusedConnectionException(String s) {
		super(s);
		// TODO Auto-generated constructor stub
	}

}
