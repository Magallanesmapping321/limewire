package com.limegroup.gnutella.archive;

public class UnsupportedFormatException extends IllegalArgumentException {

	private static final long serialVersionUID = 8291771567747414794L;

}
