package com.limegroup.gnutella.archive;

import java.io.IOException;

public class DirectoryChangeFailedException extends IOException {

	private static final long serialVersionUID = 2754710183495849898L;

	public DirectoryChangeFailedException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DirectoryChangeFailedException(String s) {
		super(s);
		// TODO Auto-generated constructor stub
	}

}
